import mitt from "mitt";

const mittBus = mitt();

export default mittBus;
