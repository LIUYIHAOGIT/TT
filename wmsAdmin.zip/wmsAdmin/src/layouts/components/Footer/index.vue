<template>
  <div class="footer flx-center">
    <a href="https://github.com/HalseySpicy" target="_blank"> 2023 © Geeker-Admin By Geeker Technology. </a>
  </div>
</template>

<style scoped lang="scss">
@import "./index.scss";
</style>
