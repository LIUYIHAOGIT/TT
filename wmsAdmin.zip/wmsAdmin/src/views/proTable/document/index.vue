<template>
  <div class="card content-box">
    <span class="text">
      ProTable 文档：
      <a href="https://juejin.cn/post/7166068828202336263#heading-14" target="_blank">
        https://juejin.cn/post/7166068828202336263#heading-14
      </a>
      🍒🍉🍊
    </span>
  </div>
</template>

<script setup name="proTableDocument"></script>
