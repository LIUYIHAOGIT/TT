<template>
  <div class="card content-box">
    <span class="text">
      掘金文档：
      <a href="https://juejin.cn/user/3263814531551816/posts" target="_blank">https://juejin.cn/user/3263814531551816/posts</a>
      🍒🍉🍊
    </span>
  </div>
</template>

<script setup name="juejin"></script>

<style scoped lang="scss">
@import "./index.scss";
</style>
